const hamburger = document.querySelector(".hamburger-menu");
const navMenu = document.querySelector(".navigation-menu");

hamburger.addEventListener("click", mobileMenu);

function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}
const navLink = document.querySelectorAll("a");

navLink.forEach(n => n.addEventListener("click", closeMenu));

function closeMenu() {
    hamburger-menu.classList.remove("active");
    navMenu.classList.remove("active");
}
